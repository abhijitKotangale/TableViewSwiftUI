//
//  ContentView.swift
//  SwiftUIDemo
//
//  Created by Mac on 10/07/20.
//  Copyright © 2020 Abhijit. All rights reserved.
//

import SwiftUI
import Combine

struct ContentView: View {
    
    @ObservedObject var getData = datas()
    
    var body: some View {
               
        NavigationView{
            List(getData.jsonData){ item in
                
                ListRow(name: item.login)
                
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

class datas : ObservableObject {
    @Published var jsonData = [datatype]()
    
    init() {
        let session = URLSession(configuration: .default)
        
        session.dataTask(with: URL(string: "https://api.github.com/users/hadley/orgs")!) { (data, response, error ) in
            
            do {
                let fetch = try JSONDecoder().decode([datatype].self, from: data!)
                DispatchQueue.main.async {
                    self.jsonData = fetch
                }
            }catch {
                print(error.localizedDescription)
            }
        }.resume()
        
    }
}

struct datatype: Identifiable, Decodable {
    var id : Int
    var login : String
    var node_is: String
}

struct ListRow : View{
    var name : String
    
    var body : some View {
        HStack{
            Text(name)
        }
    }
}
